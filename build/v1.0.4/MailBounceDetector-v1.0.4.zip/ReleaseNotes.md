### New in 1.0.4 (Released 2016/08/31)
* .net core support

### New in 1.0.3 (Released 2016/01/31)
* add support for detecting gmail bounces